package com.telmex.tienda.models;

public class Articulos {
	
	private String articulo;
	private String expected;
	
	public String getArticulo(){
		return articulo;		
	}
	
	public String getExpected() {
		return expected;
	}

}
